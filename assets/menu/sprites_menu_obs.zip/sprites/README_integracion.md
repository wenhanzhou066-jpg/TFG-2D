# Sprites para Operation: Black Steel — Menú

## Archivos incluidos

| Archivo              | Tamaño lógico | Uso                                      |
|----------------------|---------------|------------------------------------------|
| titulo_panel.png     | 320×40 px     | Panel del título principal               |
| boton_normal.png     | 256×28 px     | Botón en estado normal                   |
| boton_hover.png      | 256×28 px     | Botón al pasar el ratón encima           |
| boton_activo.png     | 256×28 px     | Botón seleccionado / pulsado             |
| boton_salir.png      | 256×28 px     | Botón de salir (con calavera)            |
| selector.png         | 14×28 px      | Indicador de selección (cadena+flecha)   |
| star_badge.png       | 20×20 px      | Estrella militar decorativa              |
| separator.png        | 256×6 px      | Separador de secciones (cadena de tanque)|

## Integración en Love2D (ui.lua)

```lua
-- En ui.lua o base.lua, carga los sprites una sola vez:
local sprites = {}

function UI.loadSprites()
    sprites.titulo   = love.graphics.newImage("assets/menu/titulo_panel.png")
    sprites.btn      = love.graphics.newImage("assets/menu/boton_normal.png")
    sprites.btn_h    = love.graphics.newImage("assets/menu/boton_hover.png")
    sprites.btn_a    = love.graphics.newImage("assets/menu/boton_activo.png")
    sprites.btn_exit = love.graphics.newImage("assets/menu/boton_salir.png")
    sprites.selector = love.graphics.newImage("assets/menu/selector.png")
    sprites.star     = love.graphics.newImage("assets/menu/star_badge.png")
    sprites.sep      = love.graphics.newImage("assets/menu/separator.png")

    -- Filtro nearest para que se vea pixel art nítido
    for _, img in pairs(sprites) do
        img:setFilter("nearest", "nearest")
    end
end

-- Función para dibujar un botón con sprite correcto según estado
function UI.drawButton(btn, isHovered, isExit)
    local img = isExit and sprites.btn_exit
             or isHovered and sprites.btn_h
             or sprites.btn

    local sw = btn.w / sprites.btn:getWidth()
    local sh = btn.h / sprites.btn:getHeight()

    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.draw(img, btn.x, btn.y, 0, sw, sh)

    -- Indicador de selección a la izquierda
    if isHovered then
        local selH = sprites.selector:getHeight()
        local selScale = btn.h / selH
        love.graphics.draw(sprites.selector, btn.x - 20, btn.y, 0, selScale, selScale)
    end
end

-- Función para dibujar el panel de título
function UI.drawTitlePanel(text, x, y, w, h)
    local sw = w / sprites.titulo:getWidth()
    local sh = h / sprites.titulo:getHeight()
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.draw(sprites.titulo, x, y, 0, sw, sh)
    -- Aquí encima dibuja el texto con tu fuente militar
end

-- Función para dibujar separador de sección
function UI.drawSeparator(x, y, w)
    local sw = w / sprites.sep:getWidth()
    love.graphics.setColor(1, 1, 1, 0.7)
    love.graphics.draw(sprites.sep, x, y, 0, sw, 1)
end
```

## Integración de sonido en audio.lua

```lua
-- Carga de sonidos de menú
local sounds = {}

function Audio.loadMenuSounds()
    -- Necesitas estos archivos .ogg en assets/sounds/menu/
    sounds.click   = love.audio.newSource("assets/sounds/menu/click.ogg",   "static")
    sounds.hover   = love.audio.newSource("assets/sounds/menu/hover.ogg",    "static")
    sounds.back    = love.audio.newSource("assets/sounds/menu/back.ogg",     "static")
    sounds.confirm = love.audio.newSource("assets/sounds/menu/confirm.ogg",  "static")

    sounds.click:setVolume(0.6)
    sounds.hover:setVolume(0.3)
    sounds.back:setVolume(0.5)
    sounds.confirm:setVolume(0.7)
end

function Audio.playMenuClick()
    sounds.click:stop()
    sounds.click:play()
end

function Audio.playMenuHover()
    sounds.hover:stop()
    sounds.hover:play()
end

function Audio.playMenuBack()
    sounds.back:stop()
    sounds.back:play()
end
```

## Uso en principal.lua / configuracion.lua

```lua
-- En el keypressed o mousepressed de cada menú:
function Menu.Principal:keypressed(key)
    if key == "up" then
        self.selected = math.max(1, self.selected - 1)
        Audio.playMenuHover()
    elseif key == "down" then
        self.selected = math.min(#self.opciones, self.selected + 1)
        Audio.playMenuHover()
    elseif key == "return" or key == "space" then
        Audio.playMenuClick()
        self:seleccionar()
    elseif key == "escape" then
        Audio.playMenuBack()
        self:volver()
    end
end
```

## Notas
- Copia los .png a: `assets/menu/`
- Los sprites usan escala 3x internamente (cada "píxel" = 3×3 px reales),
  lo que permite escalarlos con `love.graphics.draw` sin perder nitidez
- Usa siempre `img:setFilter("nearest", "nearest")` para pixel art nítido
